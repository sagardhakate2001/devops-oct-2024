sum = 5 + 10
print(f"{sum} is addition of 5 and 10")